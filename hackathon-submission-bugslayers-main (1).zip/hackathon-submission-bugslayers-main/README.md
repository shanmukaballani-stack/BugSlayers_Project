[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/1Fgu3-bk)
[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-2e0aaae1b6195c2367325f4f02e2d04e9abb55f0b24a779b69b11b9e10269abc.svg)](https://classroom.github.com/online_ide?assignment_repo_id=23293318&assignment_repo_type=AssignmentRepo)
# submission-template
This is the main submission for AI Hackathon 2026.  Rules: - All code must be in this repository - README must be complete - Demo must work - No external links (Drive, etc.)  Tracks: - Traffic AI - MCP Workflow AI - Medium &amp; Easy tracks  Build a working system, not just an idea.
